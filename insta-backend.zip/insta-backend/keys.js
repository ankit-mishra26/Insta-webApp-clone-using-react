module.exports = {
    mongoUrl: "mongodb+srv://FlyingPanda730:UgpngUX6DVAx1Xq0@cluster0.ormku05.mongodb.net/?retryWrites=true&w=majority",
    Jwt_secret: "faslkfocvneofu"

};